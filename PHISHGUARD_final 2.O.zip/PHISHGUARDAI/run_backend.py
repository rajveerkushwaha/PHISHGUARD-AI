import os
from backend.app import create_app

if __name__ == "__main__":
	# Ensure dotenv is respected via backend.config loader
	app = create_app()
	host = os.getenv("HOST", "0.0.0.0")
	port = int(os.getenv("PORT", "5000"))
	debug = os.getenv("DEBUG", "true").lower() == "true"
	app.run(host=host, port=port, debug=debug)
