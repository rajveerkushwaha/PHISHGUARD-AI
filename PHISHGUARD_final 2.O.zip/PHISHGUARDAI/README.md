# PhishGuard

Full-stack phishing detection system: Flask backend with VirusTotal integration and ML heuristic, React dashboard, and Chrome MV3 extension.

## Prerequisites
- Python 3.11+
- Node.js 18+
- (Optional) Docker

## Backend (Flask)
1. Create a virtual environment and install dependencies:
```
python -m venv .venv
. .venv/Scripts/activate
pip install -r backend/requirements.txt
```
2. Set environment variables (Windows PowerShell):
```
$env:VIRUSTOTAL_API_KEY="<YOUR_KEY>"
$env:DEBUG="true"
$env:HOST="0.0.0.0"
$env:PORT="5000"
```
3. Run the server:
```
python run_backend.py
```

Endpoints:
- POST /scan/url {"url": "http://example.com"}
- POST /scan/email {"text": "..."}
- GET /history

## Frontend (React + Vite)
```
cd frontend
npm i
npm run dev
```
- Opens at http://localhost:5173 (API base defaults to http://localhost:5000)

## Chrome Extension (MV3)
1. Go to chrome://extensions
2. Enable Developer Mode
3. Load unpacked → select `extension/`
4. Click the extension icon to scan current tab or input a URL

## Docker
```
# Set your VirusTotal key for docker-compose
$env:VIRUSTOTAL_API_KEY="<YOUR_KEY>"
docker compose up --build
```
- Backend: http://localhost:5000
- Frontend: http://localhost:5173

## Notes
- BERT model is optional; heuristics are enabled by default (ENABLE_BERT=false).
- SQLite database stored at `backend/database.db` (or Docker volume `/data/database.db`).
