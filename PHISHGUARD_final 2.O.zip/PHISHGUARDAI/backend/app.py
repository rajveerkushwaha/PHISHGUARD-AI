from flask import Flask, request, jsonify
from flask_cors import CORS

from .config import config
from .db import init_db, save_scan, fetch_history
from .services.virustotal import check_virustotal
from .services.ml import classify_text, extract_first_url
from .utils.risk import combine_results


def create_app() -> Flask:
	app = Flask(__name__)
	CORS(app, resources={r"*": {"origins": config.CORS_ORIGINS}})
	init_db()

	@app.get("/")
	def health():
		return {"status": "ok"}

	@app.post("/scan/url")
	def scan_url():
		data = request.get_json(force=True, silent=True) or {}
		url = (data.get("url") or "").strip()
		if not url:
			return jsonify({"error": "url is required"}), 400

		vt = check_virustotal(url)
		ml = classify_text(url)
		score, label, reason_combo = combine_results(vt, ml)
		details = {"virustotal": vt, "ml": ml}
		scan_id = save_scan("url", url, label, reason_combo, score, str(details))
		return jsonify({
			"id": scan_id,
			"input_type": "url",
			"url": url,
			"result": label,
			"risk_score": round(score, 3),
			"reason": reason_combo,
			"details": details,
		})

	@app.post("/scan/email")
	def scan_email():
		data = request.get_json(force=True, silent=True) or {}
		text = (data.get("text") or "").strip()
		if not text:
			return jsonify({"error": "text is required"}), 400

		first_url = extract_first_url(text)
		vt = check_virustotal(first_url) if first_url else {"success": False, "verdict": "unknown", "stats": {}, "reason": "no url"}
		ml = classify_text(text)
		score, label, reason_combo = combine_results(vt, ml)
		details = {"virustotal": vt, "ml": ml, "first_url": first_url}
		scan_id = save_scan("email", text[:2048], label, reason_combo, score, str(details))
		return jsonify({
			"id": scan_id,
			"input_type": "email",
			"result": label,
			"risk_score": round(score, 3),
			"reason": reason_combo,
			"details": details,
		})

	@app.get("/history")
	def history():
		limit = int(request.args.get("limit", 100))
		rows = fetch_history(limit=limit)
		return jsonify(rows)

	return app


if __name__ == "__main__":
	flask_app = create_app()
	flask_app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG)



