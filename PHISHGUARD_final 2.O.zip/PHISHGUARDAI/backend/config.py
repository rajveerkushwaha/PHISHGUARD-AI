import os
from dotenv import load_dotenv

# Load backend/.env explicitly if present
_env_path = os.path.join(os.path.dirname(__file__), ".env")
if os.path.exists(_env_path):
	load_dotenv(_env_path)
else:
	load_dotenv()

class Config:
	DEBUG = os.getenv("DEBUG", "false").lower() == "true"
	HOST = os.getenv("HOST", "0.0.0.0")
	PORT = int(os.getenv("PORT", "5000"))

	CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*")

	DATABASE_PATH = os.getenv("DATABASE_PATH", os.path.join(os.path.dirname(__file__), "database.db"))

	VIRUSTOTAL_API_KEY = os.getenv("VIRUSTOTAL_API_KEY", "94346a8a2cdcb0c44e152d6633152a64098360a52766e71636e271fd9b75f040")

	ENABLE_BERT = os.getenv("ENABLE_BERT", "false").lower() == "true"
	BERT_MODEL_NAME = os.getenv("BERT_MODEL_NAME", "distilbert-base-uncased")

	VT_WEIGHT = float(os.getenv("VT_WEIGHT", "0.7"))
	ML_WEIGHT = float(os.getenv("ML_WEIGHT", "0.3"))

config = Config()
