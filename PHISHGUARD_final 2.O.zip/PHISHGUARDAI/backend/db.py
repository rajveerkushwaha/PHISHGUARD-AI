import sqlite3
from datetime import datetime
from typing import List, Dict, Any

from .config import config


def _get_connection() -> sqlite3.Connection:
	conn = sqlite3.connect(config.DATABASE_PATH, check_same_thread=False)
	conn.row_factory = sqlite3.Row
	return conn


def init_db() -> None:
	with _get_connection() as conn:
		conn.execute(
			"""
			CREATE TABLE IF NOT EXISTS scans (
				id INTEGER PRIMARY KEY AUTOINCREMENT,
				input_type TEXT NOT NULL,
				input_value TEXT NOT NULL,
				result TEXT NOT NULL,
				reason TEXT NOT NULL,
				risk_score REAL NOT NULL,
				details TEXT,
				timestamp DATETIME NOT NULL
			);
			"""
		)
		conn.commit()


def save_scan(input_type: str, input_value: str, result: str, reason: str, risk_score: float, details: str = "") -> int:
	with _get_connection() as conn:
		cursor = conn.execute(
			"""
			INSERT INTO scans (input_type, input_value, result, reason, risk_score, details, timestamp)
			VALUES (?, ?, ?, ?, ?, ?, ?)
			""",
			(input_type, input_value, result, reason, risk_score, details, datetime.utcnow().isoformat()),
		)
		conn.commit()
		return cursor.lastrowid


def fetch_history(limit: int = 100) -> List[Dict[str, Any]]:
	with _get_connection() as conn:
		cur = conn.execute(
			"SELECT id, input_type, input_value, result, reason, risk_score, details, timestamp FROM scans ORDER BY id DESC LIMIT ?",
			(limit,),
		)
		rows = [dict(r) for r in cur.fetchall()]
		return rows



