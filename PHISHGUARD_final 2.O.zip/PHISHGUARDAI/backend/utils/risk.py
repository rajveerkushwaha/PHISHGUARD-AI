from typing import Dict, Any, Tuple

from ..config import config


def _vt_to_score(vt_verdict: str) -> float:
	mapping = {"malicious": 0.95, "suspicious": 0.7, "unknown": 0.5, "safe": 0.1}
	return mapping.get(vt_verdict, 0.5)


def _score_to_label(score: float) -> str:
	if score >= 0.75:
		return "malicious"
	if score >= 0.45:
		return "suspicious"
	return "safe"


def combine_results(vt_result: Dict[str, Any], ml_result: Dict[str, Any]) -> Tuple[float, str, str]:
	vt_score = _vt_to_score(vt_result.get("verdict", "unknown"))
	ml_score = float(ml_result.get("score", 0.5))

	score = config.VT_WEIGHT * vt_score + config.ML_WEIGHT * ml_score
	score = max(0.0, min(score, 1.0))
	label = _score_to_label(score)

	reason = f"VirusTotal={vt_result.get('verdict')} (w={config.VT_WEIGHT}) + ML={ml_result.get('label')} (w={config.ML_WEIGHT})"
	return score, label, reason
