import base64
import json
from typing import Dict, Any

import requests

from ..config import config


def _url_to_id(url: str) -> str:
	url_bytes = url.encode("utf-8")
	b64 = base64.urlsafe_b64encode(url_bytes).decode("utf-8").strip("=")
	return b64


def check_virustotal(url: str) -> Dict[str, Any]:
	if not config.VIRUSTOTAL_API_KEY:
		return {
			"success": False,
			"reason": "VirusTotal API key not configured",
			"stats": {"harmless": 0, "malicious": 0, "suspicious": 0, "undetected": 0, "timeout": 0},
			"verdict": "unknown",
		}

	headers = {"x-apikey": config.VIRUSTOTAL_API_KEY}
	url_id = _url_to_id(url)
	vt_url = f"https://www.virustotal.com/api/v3/urls/{url_id}"
	try:
		resp = requests.get(vt_url, headers=headers, timeout=12)
		if resp.status_code == 404:
			submit_resp = requests.post("https://www.virustotal.com/api/v3/urls", headers=headers, data={"url": url}, timeout=12)
			submit_resp.raise_for_status()
			resp = requests.get(vt_url, headers=headers, timeout=12)
		resp.raise_for_status()
		data = resp.json()
		attributes = data.get("data", {}).get("attributes", {})
		stats = attributes.get("last_analysis_stats", {}) or {}
		stats = {
			"harmless": int(stats.get("harmless", 0)),
			"malicious": int(stats.get("malicious", 0)),
			"suspicious": int(stats.get("suspicious", 0)),
			"undetected": int(stats.get("undetected", 0)),
			"timeout": int(stats.get("timeout", 0)),
		}
		if stats["malicious"] > 0:
			verdict = "malicious"
		elif stats["suspicious"] > 0:
			verdict = "suspicious"
		elif stats["harmless"] > 0 and stats["undetected"] == 0:
			verdict = "safe"
		else:
			verdict = "unknown"
		return {
			"success": True,
			"verdict": verdict,
			"stats": stats,
			"reason": f"VirusTotal analysis: {json.dumps(stats)}",
		}
	except requests.RequestException as exc:
		return {
			"success": False,
			"reason": f"VirusTotal request failed: {exc}",
			"stats": {"harmless": 0, "malicious": 0, "suspicious": 0, "undetected": 0, "timeout": 0},
			"verdict": "unknown",
		}



