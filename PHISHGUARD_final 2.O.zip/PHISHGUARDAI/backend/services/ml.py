import os
import re
from typing import Dict, Any

from ..config import config

_transformers_pipeline = None


def _load_transformers_pipeline():
	global _transformers_pipeline
	if _transformers_pipeline is not None:
		return _transformers_pipeline
	if not config.ENABLE_BERT:
		return None
	try:
		from transformers import pipeline
		model_name = os.getenv("BERT_MODEL_NAME", config.BERT_MODEL_NAME)
		_transformers_pipeline = pipeline("text-classification", model=model_name)
		return _transformers_pipeline
	except Exception:
		_transformers_pipeline = None
		return None


_PHISHING_KEYWORDS = {
	"verify your account",
	"click here",
	"urgent action required",
	"update your payment",
	"password expires",
	"suspended",
	"login immediately",
	"congratulations",
	"winner",
	"free",
	"limited time",
}

_SUSPICIOUS_DOMAINS = {"bit.ly", "goo.gl", "t.co", "tinyurl.com", "ow.ly", "is.gd"}

_URL_REGEX = re.compile(r"https?://[^\s]+", re.IGNORECASE)
_DOMAIN_REGEX = re.compile(r"https?://([^/]+)")


def _heuristic_score(text: str) -> float:
	text_lower = text.lower()
	score = 0.0

	keyword_hits = sum(1 for kw in _PHISHING_KEYWORDS if kw in text_lower)
	score += min(keyword_hits * 0.15, 0.5)

	urls = _URL_REGEX.findall(text)
	if urls:
		score += 0.1
		for u in urls:
			m = _DOMAIN_REGEX.match(u)
			if not m:
				continue
			domain = m.group(1).lower()
			if domain in _SUSPICIOUS_DOMAINS:
				score += 0.2
			if domain.count("-") >= 2:
				score += 0.1
			if any(part.isdigit() for part in domain.split(".")):
				score += 0.05

	if re.search(r"@|\$|%|\*|!|\?|\^", text):
		score += 0.05

	return max(0.0, min(score, 1.0))


def classify_text(text: str) -> Dict[str, Any]:
	nlp = _load_transformers_pipeline()
	if nlp is not None:
		try:
			result = nlp(text)[0]
			label = result.get("label", "SAFE").upper()
			raw_score = float(result.get("score", 0.5))
			phishing_score = raw_score if "NEG" in label or "PHISH" in label else (1.0 - raw_score)
			phishing_score = max(0.0, min(phishing_score, 1.0))
			return {
				"success": True,
				"label": "phishing" if phishing_score >= 0.6 else ("suspicious" if phishing_score >= 0.4 else "safe"),
				"score": phishing_score,
				"reason": f"Transformers-based classification (score={phishing_score:.2f})",
			}
		except Exception:
			pass

	score = _heuristic_score(text)
	label = "phishing" if score >= 0.6 else ("suspicious" if score >= 0.4 else "safe")
	return {"success": True, "label": label, "score": score, "reason": f"Heuristic analysis (score={score:.2f})"}


def extract_first_url(text: str) -> str:
	match = _URL_REGEX.search(text)
	return match.group(0) if match else ""



