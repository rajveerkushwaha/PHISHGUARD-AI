import React, { useEffect, useState } from 'react'
import { scanUrl, scanEmail, fetchHistory } from './api'

const Badge = ({ label }) => {
  const color = label === 'malicious' ? 'danger' : label === 'suspicious' ? 'warning' : 'success'
  return <span className={`badge text-bg-${color} text-uppercase`}>{label}</span>
}

const History = ({ items }) => (
  <div className="table-responsive mt-3">
    <table className="table table-sm table-striped align-middle">
      <thead>
        <tr>
          <th>ID</th>
          <th>Type</th>
          <th>Input</th>
          <th>Result</th>
          <th>Risk</th>
          <th>Reason</th>
          <th>Time</th>
        </tr>
      </thead>
      <tbody>
        {items.map(row => (
          <tr key={row.id}>
            <td>{row.id}</td>
            <td>{row.input_type}</td>
            <td style={{maxWidth: 320, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'}}>{row.input_value}</td>
            <td><Badge label={row.result} /></td>
            <td>{(row.risk_score ?? 0).toFixed(2)}</td>
            <td style={{maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'}}>{row.reason}</td>
            <td>{row.timestamp}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
)

function friendly(verdict) {
  const label = (verdict?.result || 'safe').toLowerCase()
  let advice
  switch (label) {
    case 'malicious':
      advice = 'Close this page and do not enter any personal information.'
      break
    case 'suspicious':
      advice = 'Only proceed if you trust it. Avoid entering passwords or payment details.'
      break
    default:
      advice = 'No known threats found.'
  }
  return advice
}

export default function App() {
  const [url, setUrl] = useState('')
  const [email, setEmail] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [history, setHistory] = useState([])
  const [error, setError] = useState('')

  const reloadHistory = async () => {
    try {
      const rows = await fetchHistory()
      setHistory(rows)
    } catch (e) {
      // ignore
    }
  }

  useEffect(() => { reloadHistory() }, [])

  const onScanUrl = async (e) => {
    e.preventDefault()
    setError(''); setResult(null); setLoading(true)
    try {
      const data = await scanUrl(url)
      setResult(data)
      await reloadHistory()
    } catch (e) {
      setError(e?.response?.data?.error || e.message)
    } finally { setLoading(false) }
  }

  const onScanEmail = async (e) => {
    e.preventDefault()
    setError(''); setResult(null); setLoading(true)
    try {
      const data = await scanEmail(email)
      setResult(data)
      await reloadHistory()
    } catch (e) {
      setError(e?.response?.data?.error || e.message)
    } finally { setLoading(false) }
  }

  return (
    <div className="container py-4">
      <h1 className="mb-3">PhishGuard Dashboard</h1>
      <div className="row g-4">
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Scan URL</h5>
              <form onSubmit={onScanUrl} className="d-flex gap-2">
                <input className="form-control" placeholder="https://example.com" value={url} onChange={e => setUrl(e.target.value)} />
                <button className="btn btn-primary" disabled={loading}>Scan</button>
              </form>
            </div>
          </div>
          <div className="card mt-3">
            <div className="card-body">
              <h5 className="card-title">Scan Email Text</h5>
              <form onSubmit={onScanEmail}>
                <textarea className="form-control mb-2" rows="5" placeholder="Paste email content here" value={email} onChange={e => setEmail(e.target.value)} />
                <button className="btn btn-primary" disabled={loading}>Scan</button>
              </form>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Result</h5>
              {loading && <div>Scanning...</div>}
              {error && <div className="alert alert-danger">{error}</div>}
              {result && (
                <div>
                  <div className="mb-2">Verdict: <Badge label={result.result} /></div>
                  <div className="mb-2">Risk score: <strong>{(result.risk_score ?? 0).toFixed(2)}</strong></div>
                  <div className="mb-1">Recommendation: <strong>{friendly(result)}</strong></div>
                  <div className="small text-muted">Details: {result.reason}</div>
                </div>
              )}
            </div>
          </div>
          <div className="card mt-3">
            <div className="card-body">
              <h5 className="card-title">History</h5>
              <History items={history} />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
