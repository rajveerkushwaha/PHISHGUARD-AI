import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:5000'

export const scanUrl = async (url) => {
  const { data } = await axios.post(`${API_BASE}/scan/url`, { url })
  return data
}

export const scanEmail = async (text) => {
  const { data } = await axios.post(`${API_BASE}/scan/email`, { text })
  return data
}

export const fetchHistory = async () => {
  const { data } = await axios.get(`${API_BASE}/history?limit=100`)
  return data
}
