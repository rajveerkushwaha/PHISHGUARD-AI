function verdictBadge(v) {
	const label = (v || 'safe').toLowerCase()
	const cls = label === 'malicious' ? 'malicious' : label === 'suspicious' ? 'suspicious' : 'safe'
	return `<span class="badge ${cls}">${label.toUpperCase()}</span>`
}

function scanViaBackground(url) {
	return new Promise((resolve, reject) => {
		chrome.runtime.sendMessage({ type: 'scan-url', url }, (resp) => {
			if (!resp || !resp.ok) {
				return reject(new Error(resp?.error || 'Scan failed'))
			}
			resolve(resp.data)
		})
	})
}

function render(items) {
	const tbody = document.getElementById('rows')
	tbody.innerHTML = ''
	if (!items || items.length === 0) {
		const tr = document.createElement('tr')
		tr.innerHTML = `<td colspan="5" class="muted">No recent sites found.</td>`
		tbody.appendChild(tr)
		return
	}
	for (const h of items) {
		const tr = document.createElement('tr')
		const time = new Date(h.lastVisitTime || Date.now()).toLocaleString()
		tr.innerHTML = `
			<td>${time}</td>
			<td>${h.title ? h.title.replace(/</g,'&lt;') : ''}</td>
			<td style="max-width:420px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${h.url}</td>
			<td><button data-url="${h.url}">Scan</button></td>
			<td class="verdict"></td>
		`
		tr.querySelector('button').addEventListener('click', async (e) => {
			const btn = e.currentTarget
			const cell = tr.querySelector('.verdict')
			btn.disabled = true
			btn.textContent = 'Scanning...'
			try {
				const data = await scanViaBackground(btn.dataset.url)
				cell.innerHTML = verdictBadge(data.result)
				cell.title = `Risk ${(data.risk_score ?? 0).toFixed(2)} — ${data.reason}`
			} catch (err) {
				cell.textContent = 'Error'
			} finally {
				btn.textContent = 'Scan'
				btn.disabled = false
			}
		})
		tbody.appendChild(tr)
	}
}

async function loadHistory(limit = 25) {
	return new Promise((resolve) => {
		if (!chrome.history || !chrome.history.search) {
			resolve([])
			return
		}
		chrome.history.search({ text: '', maxResults: limit, startTime: 0 }, (results) => {
			// De-duplicate by URL, keep latest visit
			const map = new Map()
			for (const r of results) {
				if (!r.url || !/^https?:\/\//i.test(r.url)) continue
				const prev = map.get(r.url)
				if (!prev || (r.lastVisitTime || 0) > (prev.lastVisitTime || 0)) map.set(r.url, r)
			}
			resolve(Array.from(map.values()).sort((a,b) => (b.lastVisitTime||0)-(a.lastVisitTime||0)))
		})
	})
}

document.getElementById('load').addEventListener('click', async () => {
	const limit = parseInt(document.getElementById('limit').value || '25', 10)
	document.getElementById('rows').innerHTML = '<tr><td colspan="5">Loading…</td></tr>'
	const items = await loadHistory(limit)
	render(items)
})

;(async () => {
	document.getElementById('rows').innerHTML = '<tr><td colspan="5">Loading…</td></tr>'
	const items = await loadHistory(25)
	render(items)
	if (!chrome.history || !chrome.history.search) {
		const tbody = document.getElementById('rows')
		tbody.innerHTML = '<tr><td colspan="5" class="muted">History permission not available. Please reload the extension after allowing permissions.</td></tr>'
	}
})()
