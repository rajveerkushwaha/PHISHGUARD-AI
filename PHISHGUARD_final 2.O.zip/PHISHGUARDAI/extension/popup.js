const API_BASE = 'http://localhost:5000'

function humanize(data) {
	const label = (data?.result || 'safe').toLowerCase()
	const risk = Number(data?.risk_score ?? 0)
	let title, advice
	switch (label) {
		case 'malicious':
			title = 'Dangerous site detected'
			advice = 'Close this page and do not enter any personal information.'
			break
		case 'suspicious':
			title = 'Be careful — this could be a phishing site'
			advice = 'Only proceed if you trust it. Avoid entering passwords or payment details.'
			break
		default:
			title = 'Looks safe'
			advice = 'No known threats found.'
	}
	return { label, risk, title, advice }
}

function renderResult(container, data) {
	if (!data) {
		container.innerHTML = '<div class="muted">No scan yet.</div>'
		return
	}
	const { label, risk, title, advice } = humanize(data)
	const cls = label === 'malicious' ? 'malicious' : label === 'suspicious' ? 'suspicious' : 'safe'
	container.innerHTML = `
		<div>Verdict: <span class="badge ${cls}">${label.toUpperCase()}</span></div>
		<div style="margin-top:6px">${title}</div>
		<div class="muted">Recommendation: ${advice}</div>
		<details style="margin-top:6px">
			<summary>Details</summary>
			<div>Risk: <strong>${risk.toFixed(2)}</strong></div>
			<div class="muted">${data.reason}</div>
		</details>
	`
}

async function scanUrl(url) {
	const res = await fetch(`${API_BASE}/scan/url`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url }) })
	if (!res.ok) throw new Error('Scan failed')
	return res.json()
}

document.getElementById('scanCustom').addEventListener('click', async () => {
	const input = document.getElementById('customUrl')
	const resultEl = document.getElementById('result')
	resultEl.textContent = 'Scanning...'
	try {
		const data = await scanUrl(input.value)
		renderResult(resultEl, data)
	} catch (e) {
		resultEl.textContent = 'Error: ' + e.message
	}
})

document.getElementById('scanTab').addEventListener('click', async () => {
	const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
	const url = tab?.url
	const resultEl = document.getElementById('result')
	if (!url) {
		resultEl.textContent = 'No active tab URL'
		return
	}
	resultEl.textContent = 'Scanning...'
	try {
		const data = await scanUrl(url)
		renderResult(resultEl, data)
	} catch (e) {
		resultEl.textContent = 'Error: ' + e.message
	}
})

// Moved from inline <script> to satisfy MV3 CSP
const historyLink = document.getElementById('openHistory')
if (historyLink) {
	historyLink.addEventListener('click', (e) => {
		e.preventDefault()
		chrome.tabs.create({ url: chrome.runtime.getURL('history.html') })
	})
}
