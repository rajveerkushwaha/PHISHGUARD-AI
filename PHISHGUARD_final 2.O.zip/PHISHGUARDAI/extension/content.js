(function() {
	try {
		const isHttp = location.protocol === 'http:' || location.protocol === 'https:'
		if (!isHttp) return

		chrome.runtime.sendMessage({ type: 'scan-url', url: location.href }, (resp) => {
			if (!resp || !resp.ok) return
			injectBanner(resp.data)
		})

		function humanize(result) {
			const label = (result.result || 'safe').toLowerCase()
			const risk = Number(result.risk_score ?? 0)
			let title, advice
			switch (label) {
				case 'malicious':
					title = 'Dangerous site detected'
					advice = 'Close this page and do not enter any personal information.'
					break
				case 'suspicious':
					title = 'Be careful — this could be a phishing site'
					advice = 'Only proceed if you trust it. Avoid entering passwords or payment details.'
					break
				default:
					title = 'Looks safe'
					advice = 'No known threats found.'
			}
			return { label, risk, title, advice }
		}

		function injectBanner(result) {
			if (!result || document.getElementById('phishguard-banner')) return
			const { label, risk, title, advice } = humanize(result)
			const colors = { malicious: { bg: '#dc3545', fg: '#fff' }, suspicious: { bg: '#ffc107', fg: '#000' }, safe: { bg: '#22c55e', fg: '#fff' } }
			const { bg, fg } = colors[label] || colors.safe

			const card = document.createElement('div')
			card.id = 'phishguard-banner'
			card.style.cssText = `position:fixed;top:12px;right:12px;z-index:2147483647;`+
								`max-width:min(92vw, 360px);background:${bg};color:${fg};`+
								`border-radius:12px;padding:12px 14px;box-shadow:0 8px 24px rgba(0,0,0,.25);`+
								`font:14px/1.45 system-ui,Arial;display:flex;gap:10px;align-items:flex-start;`

			const badge = document.createElement('span')
			badge.textContent = label.toUpperCase()
			badge.style.cssText = `flex:0 0 auto;font-weight:700;border:1px solid rgba(255,255,255,.35);`+
								`padding:2px 6px;border-radius:6px;letter-spacing:.3px`

			const content = document.createElement('div')
			content.style.cssText = 'flex:1 1 auto;display:flex;flex-direction:column;gap:2px'
			const line1 = document.createElement('div')
			line1.textContent = `${title}`
			line1.style.cssText = 'font-weight:600'
			const line2 = document.createElement('div')
			line2.textContent = `Recommendation: ${advice}`
			line2.style.cssText = 'opacity:.9'

			const detailsBtn = document.createElement('button')
			detailsBtn.textContent = 'Details'
			detailsBtn.style.cssText = 'align-self:flex-start;background:transparent;border:1px solid rgba(255,255,255,.35);color:inherit;border-radius:6px;padding:2px 8px;cursor:pointer;margin-top:4px'
			const detailsBox = document.createElement('div')
			detailsBox.style.cssText = 'margin-top:6px;display:none;opacity:.9'
			detailsBox.textContent = `Risk score: ${risk.toFixed(2)} • ${result.reason}`
			detailsBtn.addEventListener('click', () => {
				detailsBox.style.display = detailsBox.style.display === 'none' ? 'block' : 'none'
			})

			const close = document.createElement('button')
			close.textContent = '×'
			close.ariaLabel = 'Close'
			close.style.cssText = `flex:0 0 auto;background:transparent;border:none;color:${fg};`+
								`font-size:18px;cursor:pointer;line-height:1`
			close.addEventListener('click', () => { card.remove() })

			content.appendChild(line1)
			content.appendChild(line2)
			content.appendChild(detailsBtn)
			content.appendChild(detailsBox)

			card.appendChild(badge)
			card.appendChild(content)
			card.appendChild(close)

			document.body.appendChild(card)
		}
	} catch (e) {
		// no-op
	}
})()
